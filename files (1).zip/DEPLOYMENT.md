# ShelfCheck — Netlify Deployment Guide

## Files in this package
- `shelfcheck-combined.html` — the main tool (rename to `index.html` in your repo root)
- `netlify.toml` — Netlify build config
- `netlify/functions/claude.js` — serverless API proxy

## Setup Steps

### 1. Folder structure in your repo
```
/
├── index.html                    (rename shelfcheck-combined.html)
├── netlify.toml
└── netlify/
    └── functions/
        └── claude.js
```

### 2. Set your Anthropic API key in Netlify
1. Go to your site in Netlify dashboard
2. Site Settings → Environment Variables
3. Add: `ANTHROPIC_API_KEY` = your key (starts with `sk-ant-...`)

### 3. Deploy
Push all files to your repo — Netlify auto-deploys.

## Why this setup?
The HTML file calls `/api/claude` (a relative URL).
`netlify.toml` routes that to `/.netlify/functions/claude`.
The function adds your secret API key server-side before forwarding to Anthropic.
Your API key is never exposed in the browser.
